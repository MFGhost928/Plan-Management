# planmanagement
## Material Design + GreenDao3.0 + ViewDragHelper
## 一款记录工作生活计划的Android APP
![img](https://raw.githubusercontent.com/lrh/planmanagement/1c973a19fdd0d2389c22956faf0d8479cfacd8d5/planmanagementpre.gif)

package com.lrh.planmanagement.utils;

public interface Constants {
    int token_today = 0x00000000;
    int token_tomorrow = 0x00000001;
    int token_month = 0x00000002;
    int token_completed= 0x00000003;
    int token_uncompleted = 0x00000004;
    int token_date = 0x00000005;
}
